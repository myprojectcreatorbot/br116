// BY @LONEXSSTUDIO
#pragma once
#include <cstdint>

namespace ClientConfig
{
    inline constexpr char ServerHost[] = "5.182.4.101";
inline constexpr uint16_t ServerPort = 1941;
inline constexpr char ServerName[] = "GROZNY";

