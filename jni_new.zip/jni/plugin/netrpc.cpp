// ONLINE RUSSIA (Black Russia client)

#include "netrpc.h"
#include "xorstr.h"

#include "plugin.h"
#include "common.h"
#include "netgame.h"
#include "game/chat.h"
#include "vendor/RakNet/StringCompressor.h"
#include <cmath>
#include <cstdio>
#include <cstring>

extern RakClientInterface* pRakClient;

namespace
{
    void OrBlockedRpc(RPCParameters* p)
    {
        static unsigned int logged = 0;
        if (logged < 64u) {
            ++logged;
        }
    }

#if !defined(__aarch64__)
    // 32 бит (armeabi-v7a) 16.116: обработчик из 64-битной сборки -> тот же обработчик (тот же id RPC) в 32-битной
    struct GameRpcPair { uintptr_t arm64; uintptr_t arm32; };
    const GameRpcPair kGameRpc32[] = {
        {0x1633180, 0xDE16FD}, // RPC 421
        {0x16338B0, 0xDE1C59}, // RPC 401
        {0x1633A94, 0xDE1D8D}, // RPC 326
        {0x1633B70, 0xDE1E1D}, // RPC 360
        {0x1633D20, 0xDE1F5D}, // RPC 344
        {0x1633D44, 0xDE1F81}, // RPC 419
        {0x1634158, 0xDE22F1}, // RPC 325
        {0x1634440, 0xDE2551}, // RPC 319
        {0x16357CC, 0xDE3B71}, // RPC 329
        {0x16366F8, 0xDE4849}, // RPC 382
        {0x1636814, 0xDE4905}, // RPC 409
        {0x1636908, 0xDE499D}, // RPC 435
        {0x16369D8, 0xDE4A25}, // RPC 448
        {0x1636BFC, 0xDE4BAD}, // RPC 433
        {0x1636CDC, 0xDE4C35}, // RPC 303
        {0x1636DC0, 0xDE4CC1}, // RPC 377
        {0x1636FA8, 0xDE4E3D}, // RPC 373
        {0x1637070, 0xDE4EB1}, // RPC 432
        {0x1637244, 0xDE4FFD}, // RPC 417
        {0x16373A4, 0xDE50E1}, // RPC 322
        {0x1637460, 0xDE5151}, // RPC 337
        {0x1637C20, 0xDE57E5}, // RPC 354
        {0x1637CEC, 0xDE5861}, // RPC 349
        {0x1637DFC, 0xDE5921}, // RPC 376
        {0x1637F90, 0xDE5A49}, // RPC 372
        {0x16380D0, 0xDE5B4D}, // RPC 310
        {0x16381D0, 0xDE5BED}, // RPC 405
        {0x16382CC, 0xDE5C7D}, // RPC 365
        {0x163841C, 0xDE5D51}, // RPC 400
        {0x1638B78, 0xDE63CD}, // RPC 302
        {0x1638BB0, 0xDE63F9}, // RPC 434
        {0x1638C94, 0xDE6489}, // RPC 387
        {0x1638D5C, 0xDE64FD}, // RPC 315
        {0x1638E24, 0xDE6571}, // RPC 353
        {0x1638F08, 0xDE65FD}, // RPC 362
        {0x1638FD4, 0xDE6675}, // RPC 348
        {0x1638FF0, 0xDE6689}, // RPC 383
        {0x16390D8, 0xDE6721}, // RPC 339
        {0x163918C, 0xDE678D}, // RPC 331
        {0x1639274, 0xDE6821}, // RPC 412
        {0x1639398, 0xDE68E5}, // RPC 395
        {0x1639490, 0xDE698D}, // RPC 327
        {0x1639584, 0xDE6A2D}, // RPC 334
        {0x1639698, 0xDE6AD5}, // RPC 335
        {0x16398C0, 0xDE6C91}, // RPC 379
        {0x1639988, 0xDE6D09}, // RPC 340
        {0x1639A4C, 0xDE6D7D}, // RPC 394
        {0x1639B34, 0xDE6E0D}, // RPC 431
        {0x1639C78, 0xDE6EE5}, // RPC 424
        {0x1639E08, 0xDE6FF9}, // RPC 318
        {0x1639EC4, 0xDE7069}, // RPC 350
        {0x1639FB4, 0xDE7101}, // RPC 426
        {0x163A0A4, 0xDE7191}, // RPC 422
        {0x163A22C, 0xDE7295}, // RPC 415
        {0x163A3AC, 0xDE73BD}, // RPC 338
        {0x163A4D8, 0xDE7469}, // RPC 428
        {0x163A658, 0xDE757D}, // RPC 447
        {0x163A7D0, 0xDE765D}, // RPC 384
        {0x163A8D4, 0xDE7701}, // RPC 398
        {0x163AA2C, 0xDE77E5}, // RPC 416
        {0x163AB44, 0xDE7891}, // RPC 391
        {0x163BE68, 0xDE8A61}, // RPC 388
        {0x163C0A8, 0xDE8C71}, // RPC 443
        {0x163C1F4, 0xDE8D49}, // RPC 306
        {0x163C2C4, 0xDE8DD1}, // RPC 446
        {0x163CE90, 0xDE985D}, // RPC 330
        {0x163CF64, 0xDE98DD}, // RPC 308
        {0x163D074, 0xDE998D}, // RPC 389
        {0x163D184, 0xDE9A3D}, // RPC 402
        {0x163D28C, 0xDE9AE9}, // RPC 411
        {0x163D940, 0xDE9FA5}, // RPC 444
        {0x163E3BC, 0xDEA6ED}, // RPC 375
        {0x163E500, 0xDEA7D1}, // RPC 347
        {0x163E734, 0xDEA981}, // RPC 368
        {0x163EE3C, 0xDEAF01}, // RPC 345
        {0x163F41C, 0xDEB36D}, // RPC 311
        {0x163F564, 0xDEB455}, // RPC 336
        {0x163FA84, 0xDEB831}, // RPC 333
        {0x163FBA4, 0xDEB8FD}, // RPC 440
        {0x163FD60, 0xDEBA31}, // RPC 430
        {0x163FDD4, 0xDEBA81}, // RPC 385
        {0x1640004, 0xDEBBF1}, // RPC 304
        {0x1640078, 0xDEBC41}, // RPC 307
        {0x164026C, 0xDEBD81}, // RPC 410
        {0x1640364, 0xDEBE31}, // RPC 364
        {0x1641204, 0xDECC21}, // RPC 374
        {0x1641354, 0xDECD0D}, // RPC 313
        {0x1641D58, 0xDED459}, // RPC 429
        {0x16423A8, 0xDED961}, // RPC 323
        {0x16469B4, 0xDF1411}, // RPC 399
        {0x1646C94, 0xDF1671}, // RPC 316
        {0x1646ED4, 0xDF17E1}, // RPC 393
        {0x1647010, 0xDF18B1}, // RPC 346
        {0x16470DC, 0xDF192D}, // RPC 359
        {0x16471C0, 0xDF19B9}, // RPC 369
        {0x164728C, 0xDF1A35}, // RPC 408
        {0x1647474, 0xDF1B71}, // RPC 425
        {0x16475C4, 0xDF1C41}, // RPC 351
        {0x16476AC, 0xDF1CD9}, // RPC 366
        {0x164777C, 0xDF1D61}, // RPC 439
        {0x1647870, 0xDF1E05}, // RPC 328
    };
#endif

    uintptr_t OrGameRpc(uintptr_t offset)
    {
#if !defined(__aarch64__)
        uintptr_t mapped = 0;
        for (const GameRpcPair& pair : kGameRpc32) {
            if (pair.arm64 == offset) { mapped = pair.arm32; break; }
        }
        offset = mapped;
#endif
        return offset ? CGameAPI::m_address + offset : reinterpret_cast<uintptr_t>(&OrBlockedRpc);
    }

    const char* ToUtf8(const char* text, size_t length, size_t& outLength)
    {
        static char source[4097];
        static char result[4097 * 3];
        if (length > 4096) length = 4096;
        std::memcpy(source, text, length);
        source[length] = '\0';
        cp1251_to_utf8(result, source, static_cast<unsigned int>(length));
        outLength = std::strlen(result);
        return result;
    }

    bool RecodeText8(RakNet::BitStream& in, RakNet::BitStream& out)
    {
        uint8_t length = 0;
        char buffer[256];
        if (!in.Read(length) || !in.Read(buffer, length)) {
            return false;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(buffer, length, utfLength);
        while (utfLength > 255 && (static_cast<unsigned char>(utf[utfLength - 1]) & 0xC0) == 0x80) --utfLength;
        if (utfLength > 255) utfLength = 254;
        out.Write(static_cast<uint8_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        return true;
    }

    bool RecodeCompressedText(RakNet::BitStream& in, RakNet::BitStream& out, int maxChars)
    {
        static char text[4097];
        if (maxChars > 4096) maxChars = 4096;
        text[0] = '\0';
        if (!StringCompressor::Instance()->DecodeString(text, maxChars, &in)) {
            return false;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, std::strlen(text), utfLength);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        return true;
    }

    void CallWithPayload(RPCParameters* p, RakNet::BitStream& out, uintptr_t offset)
    {
        RPCParameters converted = *p;
        converted.input = out.GetData();
        converted.numberOfBitsOfData = out.GetNumberOfBitsUsed();
        reinterpret_cast<void(*)(RPCParameters*)>(OrGameRpc(offset))(&converted);
    }

    void DialogToNewClient(RPCParameters* p, uintptr_t offset)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 40u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        uint16_t dialogId = 0;
        uint8_t style = 0;
        if (!in.Read(dialogId) || !in.Read(style)) {
            return;
        }
        out.Write(dialogId);
        out.Write(style);
        for (int i = 0; i < 3; ++i) {
            if (!RecodeText8(in, out)) {
                return;
            }
        }
        if (!RecodeCompressedText(in, out, 4096)) {
            return;
        }
        CallWithPayload(p, out, offset);
    }

    void ClientMessageNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 64u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint32_t color = 0, length = 0;
        static char text[4097];
        if (!in.Read(color) || !in.Read(length) || length > 4096u || !in.Read(text, static_cast<int>(length))) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        RakNet::BitStream out;
        out.Write(color);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x1633B70);
    }

    void ChatBubbleNew(RPCParameters* p)
    {
        constexpr unsigned int kFixedBytes = 14u;
        if (!p || !p->input || p->numberOfBitsOfData < (kFixedBytes + 1u) * 8u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        out.Write(reinterpret_cast<const char*>(p->input), kFixedBytes);
        in.SetReadOffset(kFixedBytes * 8u);
        if (!RecodeText8(in, out)) {
            return;
        }
        CallWithPayload(p, out, 0x163E3BC);
    }

    void EditTextDrawNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 32u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t id = 0, length = 0;
        char text[1025];
        if (!in.Read(id) || !in.Read(length) || length > 1024u || !in.Read(text, length)) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        if (utfLength > 0xFFFFu) return;
        RakNet::BitStream out;
        out.Write(id);
        out.Write(static_cast<uint16_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x1637CEC);
    }

    void GameTextNew(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 96u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        int32_t style = 0, time = 0;
        uint32_t length = 0;
        static char text[1025];
        if (!in.Read(style) || !in.Read(time) || !in.Read(length) || length > 1024u ||
            !in.Read(text, static_cast<int>(length))) {
            return;
        }
        size_t utfLength = 0;
        const char* utf = ToUtf8(text, length, utfLength);
        RakNet::BitStream out;
        out.Write(style);
        out.Write(time);
        out.Write(static_cast<uint32_t>(utfLength));
        out.Write(utf, static_cast<int>(utfLength));
        CallWithPayload(p, out, 0x163A22C);
    }

    void ShowDialogNew(RPCParameters* p) { DialogToNewClient(p, 0x163E500); }
    void ShowDialogExNew(RPCParameters* p) { DialogToNewClient(p, 0x163E734); }

    void Create3DTextLabelNew(RPCParameters* p)
    {
        constexpr unsigned int kFixedBytes = 27u;
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        RakNet::BitStream out;
        out.Write(reinterpret_cast<const char*>(p->input), kFixedBytes);
        in.SetReadOffset(kFixedBytes * 8u);
        if (!RecodeCompressedText(in, out, 1024)) {
            return;
        }
        CallWithPayload(p, out, 0x1637070);
    }
}

namespace
{
    uint16_t ReadLE16(const unsigned char* data)
    {
        return static_cast<uint16_t>(data[0]) |
            static_cast<uint16_t>(static_cast<uint16_t>(data[1]) << 8u);
    }

    void SafeCreate3DTextLabel(RPCParameters* p)
    {
        constexpr unsigned int kFixedBits = 216u;
        constexpr unsigned int kMaxPacketBytes = 8192u;
        constexpr uint16_t kMaxLabelId = 3551u;
        constexpr uint16_t kMaxPlayerId = 1503u;
        constexpr uint16_t kMaxVehicleId = 1999u;
        constexpr uint16_t kInvalidId = 0xFFFFu;

        const unsigned int bits = p ? p->numberOfBitsOfData : 0u;
        const uint64_t bytes64 = (static_cast<uint64_t>(bits) + 7u) / 8u;
        if (!p || !p->input || bits <= kFixedBits || bytes64 > kMaxPacketBytes) {
            return;
        }
        const unsigned int bytes = static_cast<unsigned int>(bytes64);

        const uint16_t labelId = ReadLE16(p->input);
        const uint8_t useLOS = p->input[22];
        const uint16_t attachedPlayer = ReadLE16(p->input + 23);
        const uint16_t attachedVehicle = ReadLE16(p->input + 25);
        float x = 0.0f;
        float y = 0.0f;
        float z = 0.0f;
        float drawDistance = 0.0f;
        std::memcpy(&x, p->input + 6, sizeof(x));
        std::memcpy(&y, p->input + 10, sizeof(y));
        std::memcpy(&z, p->input + 14, sizeof(z));
        std::memcpy(&drawDistance, p->input + 18, sizeof(drawDistance));

        const bool validPlayer = attachedPlayer == kInvalidId || attachedPlayer <= kMaxPlayerId;
        const bool validVehicle = attachedVehicle == kInvalidId || attachedVehicle <= kMaxVehicleId;
        if (labelId > kMaxLabelId || useLOS > 1u || !validPlayer || !validVehicle ||
            !std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z) ||
            !std::isfinite(drawDistance)) {
            return;
        }

        RakNet::BitStream check(p->input, bytes, false);
        check.SetWriteOffset(bits);
        check.SetReadOffset(kFixedBits);
        uint16_t encodedTextBits = 0;
        if (!check.ReadCompressed(encodedTextBits) ||
            check.GetNumberOfUnreadBits() < static_cast<int>(encodedTextBits)) {
            return;
        }

        Create3DTextLabelNew(p);
    }

    void SafeWorldPlayerRemove(RPCParameters* p)
    {
        const unsigned int bits = p ? p->numberOfBitsOfData : 0;
        const unsigned int bytes = (bits + 7u) / 8u;
        if (!p || !p->input || bytes < 2u) {
            return;
        }

        const uint16_t playerId = static_cast<uint16_t>(p->input[0]) |
            static_cast<uint16_t>(static_cast<uint16_t>(p->input[1]) << 8u);
        if (playerId >= 1504u) {
            return;
        }

        CPlayerPool* pool = CNetGame::GetPlayerPool();
        CRemotePlayer* remotePlayer = pool ? pool->GetAt(playerId) : nullptr;
        if (pool && !remotePlayer) {
            return;
        }
        if (remotePlayer && !remotePlayer->m_pPlayerPed) {
            return;
        }

        reinterpret_cast<void(*)(RPCParameters*)>(OrGameRpc(0x1634158))(p);
    }
}


namespace
{
    // Called for every chat line, text draw, gang zone and streamed-in vehicle: no log line here
    // (it was a file write + logcat on the game thread each time). Blocked RPCs are still logged.
    void TraceAndCall(const char* name, uintptr_t offset, RPCParameters* params)
    {
        (void)name;
        reinterpret_cast<void(*)(RPCParameters*)>(OrGameRpc(offset))(params);
    }

	void TraceShowTextDraw(RPCParameters* p)
	{
		const unsigned int bits = p ? p->numberOfBitsOfData : 0;
		const unsigned int bytes = (bits + 7u) / 8u;

		// 65 байт данных TextDraw + 2 байта длины текста
		if(!p || !p->input || bytes < 67)
		{
			return;
		}

		const unsigned int textLength =
			static_cast<unsigned int>(p->input[65]) |
			(static_cast<unsigned int>(p->input[66]) << 8);

		// Пустой ShowTextDraw создаёт у этого клиента белый box на весь экран.
		if(textLength == 0)
		{
			return;
		}

		if(textLength > 255 || bytes < 67u + textLength)
		{
			return;
		}

		TraceAndCall("ShowTextDraw", 0x0, p);
	}

    void TraceAddGangZone(RPCParameters* p)    { TraceAndCall("AddGangZone", 0x1646ED4, p); }
    void TraceFlashGangZone(RPCParameters* p)  { TraceAndCall("FlashGangZone", 0x16470DC, p); }
    void TraceWorldVehicleAdd(RPCParameters* p)
    {
        reinterpret_cast<void(*)(RPCParameters*)>(OrGameRpc(0x16357CC))(p);
    }

}

// Game features BR has handlers for but this launcher never routed (found from the game's own RPC table).
// SA-MP has no RPC ids for most of them, so the server sends them on free ids 210-216.
namespace
{
    int g_rpcMaxHealth = 210;            // u16 player, f32 max health (the nametag bar is health / max)
    int g_rpcMaxArmour = 211;            // u16 player, f32 max armour
    int g_rpcVehicleNitro = 217;         // ONLINE RUSSIA: u16 vehicle, u8 level 0..3 — кнопка нитро (игровой RPC 444)
    int g_rpcEntityOutline = 212;        // u8 type, u16 id, u8 on; on: f32 width 0-10, f32, u8, u32 color
    int g_rpcRadioStream = 213;          // u32, str8 url, str8 name, u8 attach, u16 id, ...
    int g_rpcUpdateLabel = 214;          // u16 label, u32 color, compressed text
    int g_rpcActorAttachedObject = 215;  // like SetPlayerAttachedObject for an actor, without colors
    int g_rpcDialogEx = 216;             // same layout as ShowPlayerDialog, other game window

    uintptr_t GameHandler(uintptr_t arm32_thumb, uintptr_t arm64)
    {
        (void)arm32_thumb;
        return OrGameRpc(arm64);
    }

    // SA-MP sends lights and tires as one byte each; the game reads two bytes for each.
    void DamageVehicleToGame(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 96u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t vehicle = 0;
        uint32_t panels = 0, doors = 0;
        uint8_t lights = 0, tires = 0;
        if (!in.Read(vehicle) || !in.Read(panels) || !in.Read(doors) || !in.Read(lights) || !in.Read(tires)) {
            return;
        }
        RakNet::BitStream out;
        out.Write(vehicle);
        out.Write(panels);
        out.Write(doors);
        out.Write(static_cast<uint16_t>(lights));
        out.Write(static_cast<uint16_t>(tires));
        RPCParameters converted = *p;
        converted.input = out.GetData();
        converted.numberOfBitsOfData = out.GetNumberOfBitsUsed();
        reinterpret_cast<void(*)(RPCParameters*)>(GameHandler(0x332A45, 0x1639B34))(&converted);
    }

    // SetPlayerAttachedObject (SA-MP 113): u16 player, u32 slot, bit create,
    // [u32 model, u32 bone, f32 offset[3], f32 rot[3], f32 scale[3], u32 color1, u32 color2].
    // The 16.106 game handler (0x1640364, "Attach object RPC") reads the same fields without the
    // colors, then an optional u8 flag (1 = material/texture strings follow). Drop the colors and
    // write the flag as 0 so the first color byte is never taken for that flag.
    void SetPlayerAttachedObjectToGame(RPCParameters* p)
    {
        if (!p || !p->input || p->numberOfBitsOfData < 49u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t playerId = 0;
        uint32_t slot = 0;
        bool create = false;
        if (!in.Read(playerId) || !in.Read(slot) || !in.Read(create) || playerId >= 1504u || slot >= 10u) {
            return;
        }
        uint32_t model = 0, bone = 0;
        float values[9] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f};
        if (create) {
            if (!in.Read(model) || !in.Read(bone)) {
                return;
            }
            for (float& value : values) {
                if (!in.Read(value) || !std::isfinite(value)) {
                    return;
                }
            }
        }
        RakNet::BitStream out;
        out.Write(playerId);
        out.Write(slot);
        out.Write(create);
        out.Write(model);
        out.Write(bone);
        for (float value : values) {
            out.Write(value);
        }
        out.Write(static_cast<uint8_t>(0));
        RPCParameters converted = *p;
        converted.input = out.GetData();
        converted.numberOfBitsOfData = out.GetNumberOfBitsUsed();
        reinterpret_cast<void(*)(RPCParameters*)>(GameHandler(0x0, 0x1640364))(&converted);
    }

    // ONLINE RUSSIA: AddVehicleComponent (ScmEvent, событие 2) с деталью 1008/1009/1010 ставит
    // в игре только модель баллона — кнопки нитро нет. Включаем её тем же, что и RPC нитро сервера.
    void ScmEventToGame(RPCParameters* p)
    {
        reinterpret_cast<void(*)(RPCParameters*)>(OrGameRpc(0x1647474))(p);
        if (!p || !p->input || p->numberOfBitsOfData < 144u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t player = 0;
        uint32_t event = 0, vehicle = 0, component = 0;
        if (!in.Read(player) || !in.Read(event) || !in.Read(vehicle) || !in.Read(component)) {
            return;
        }
        if (event != 2u || vehicle == 0u || vehicle >= 2000u) {
            return;
        }
        const uint8_t level = OrNitroLevelFromComponent(component);
        if (level) {
            OrApplyVehicleNitro(p, static_cast<uint16_t>(vehicle), level);
        }
    }

    // RemoveVehicleComponent (u16 машина, u16 деталь): сняли нитро — выключить кнопку
    void RemoveComponentToGame(RPCParameters* p)
    {
        reinterpret_cast<void(*)(RPCParameters*)>(GameHandler(0x332491, 0x1639398))(p);
        if (!p || !p->input || p->numberOfBitsOfData < 32u) {
            return;
        }
        RakNet::BitStream in(p->input, (p->numberOfBitsOfData + 7u) / 8u, false);
        uint16_t vehicle = 0, component = 0;
        if (!in.Read(vehicle) || !in.Read(component)) {
            return;
        }
        if (vehicle != 0u && vehicle < 2000u && OrNitroLevelFromComponent(component)) {
            OrApplyVehicleNitro(p, vehicle, 0);
        }
    }

    void RegisterGameExtraRPCs(RakClientInterface* pInterface)
    {
        using Handler = void (*)(RPCParameters*);
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcMaxHealth, reinterpret_cast<Handler>(GameHandler(0x33A399, 0x164777C)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcMaxArmour, reinterpret_cast<Handler>(GameHandler(0x33A435, 0x1647870)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcVehicleNitro, reinterpret_cast<Handler>(GameHandler(0x0, 0x163D940)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcEntityOutline, reinterpret_cast<Handler>(GameHandler(0x339375, 0x16469B4)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcRadioStream, reinterpret_cast<Handler>(GameHandler(0x330D59, 0x1637460)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcUpdateLabel, reinterpret_cast<Handler>(GameHandler(0x331009, 0x0)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcActorAttachedObject, reinterpret_cast<Handler>(GameHandler(0x3358E9, 0x0)));
        pInterface->RegisterAsRemoteProcedureCall(&g_rpcDialogEx, ShowDialogExNew);
        // Same layout as SA-MP: SetObjectPos (45), RemoveVehicleComponent (57).
        pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectPos, reinterpret_cast<Handler>(GameHandler(0x333825, 0x163C0A8)));
        pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveComponent, RemoveComponentToGame);
        pInterface->RegisterAsRemoteProcedureCall(&RPC_DamageVehicle, DamageVehicleToGame);
    }
}

uint8_t OrNitroLevelFromComponent(uint32_t componentId)
{
    switch (componentId) {
        case 1009: return 1;   // 2X
        case 1008: return 2;   // 5X
        case 1010: return 3;   // 10X
    }
    return 0;
}

void OrApplyVehicleNitro(const RPCParameters* tmpl, uint16_t vehicleId, uint8_t level)
{
    if (vehicleId == 0 || vehicleId >= 2000 || level > 3) {
        return;
    }
    const uintptr_t handler = GameHandler(0x0, 0x163D940);   // игровой RPC 444: u16 машина, u8 уровень
    if (!handler) {
        return;
    }
    RakNet::BitStream out;
    out.Write(vehicleId);
    out.Write(level);
    RPCParameters params {};
    if (tmpl) {
        params = *tmpl;
    }
    params.input = out.GetData();
    params.numberOfBitsOfData = out.GetNumberOfBitsUsed();
    params.replyToSender = nullptr;
    reinterpret_cast<void(*)(RPCParameters*)>(handler)(&params);
}

void RegisterRPCs(RakClientInterface* pInterface)
{
  // 64 bit - ЗАМЕНЕННЫЕ оффсеты для нового билда
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrMoveObject, ((void (*)(RPCParameters*))(OrGameRpc(0x164728C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleZAngle, ((void (*)(RPCParameters*))(OrGameRpc(0x1639490))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerColor, ((void (*)(RPCParameters*))(OrGameRpc(0x163A658))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraPos, ((void (*)(RPCParameters*))(OrGameRpc(0x16380D0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetRaceCheckpoint, ((void (*)(RPCParameters*))(OrGameRpc(0x163FDD4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_StopAudioStream, OrBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraLookAt, ((void (*)(RPCParameters*))(OrGameRpc(0x16381D0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParams, ((void (*)(RPCParameters*))(OrGameRpc(0x163D184))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrAddGangZone, TraceAddGangZone);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkin, ((void (*)(RPCParameters*))(OrGameRpc(0x163841C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_UpdateScoresPingsIPs, ((void (*)(RPCParameters*))(OrGameRpc(0x1641204))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrResetPlayerWeapons, OrBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDetachTrailerFromVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x16476AC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrFlashGangZone, TraceFlashGangZone);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ConnectionRejected, ((void (*)(RPCParameters*))(OrGameRpc(0x1634440))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ServerQuit, ((void (*)(RPCParameters*))(OrGameRpc(0x1633A94))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleVelocity, ((void (*)(RPCParameters*))(OrGameRpc(0x1639584))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_Weather, ((void (*)(RPCParameters*))(OrGameRpc(0x16398C0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrResetMoney, ((void (*)(RPCParameters*))(OrGameRpc(0x1638FD4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerHealth, ((void (*)(RPCParameters*))(OrGameRpc(0x1638C94))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrStopObject, ((void (*)(RPCParameters*))(OrGameRpc(0x163C1F4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehiclePos, ((void (*)(RPCParameters*))(OrGameRpc(0x1639274))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleHealth, ((void (*)(RPCParameters*))(OrGameRpc(0x163918C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrClearPlayerAnimations, ((void (*)(RPCParameters*))(OrGameRpc(0x163F41C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorFacingAngle, ((void (*)(RPCParameters*))(OrGameRpc(0x163A0A4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerArmour, ((void (*)(RPCParameters*))(OrGameRpc(0x1638D5C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDisableMapIcon, ((void (*)(RPCParameters*))(OrGameRpc(0x164026C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScmEvent, ScmEventToGame);   // + кнопка нитро для деталей 1008-1010
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrApplyPlayerAnimation, ((void (*)(RPCParameters*))(OrGameRpc(0x163EE3C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerDeath, ((void (*)(RPCParameters*))(OrGameRpc(0x1636908))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetCheckpoint, ((void (*)(RPCParameters*))(OrGameRpc(0x163FBA4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrClearActorAnimations, ((void (*)(RPCParameters*))(OrGameRpc(0x163FA84))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemovePlayerFromVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x16390D8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerSpectating, ((void (*)(RPCParameters*))(OrGameRpc(0x163CE90))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrStopFlashGangZone, ((void (*)(RPCParameters*))(OrGameRpc(0x16471C0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_EnterVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x16366F8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ShowActor, ((void (*)(RPCParameters*))(OrGameRpc(0x1639C78))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectRotation, ((void (*)(RPCParameters*))(OrGameRpc(0x163C2C4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPosFindZ, ((void (*)(RPCParameters*))(OrGameRpc(0x163AA2C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrInterpolateCamera, ((void (*)(RPCParameters*))(OrGameRpc(0x1646C94))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorHealth, ((void (*)(RPCParameters*))(OrGameRpc(0x1639EC4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_InitGame, ((void (*)(RPCParameters*))(OrGameRpc(0x1633180))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrGivePlayerWeapon, ((void (*)(RPCParameters*))(OrGameRpc(0x1636BFC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrAttachTrailerToVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x16475C4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetTimeEx, ((void (*)(RPCParameters*))(OrGameRpc(0x1639A4C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetWeaponAmmo, ((void (*)(RPCParameters*))(OrGameRpc(0x1636CDC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrHaveSomeMoney, ((void (*)(RPCParameters*))(OrGameRpc(0x1638F08))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerWantedLevel, ((void (*)(RPCParameters*))(OrGameRpc(0x163A8D4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDialogBox, ShowDialogNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerVelocity, ((void (*)(RPCParameters*))(OrGameRpc(0x1639698))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetMapIcon, ((void (*)(RPCParameters*))(OrGameRpc(0x1640078))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldVehicleAdd, TraceWorldVehicleAdd);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDestroyObject, ((void (*)(RPCParameters*))(OrGameRpc(0x163BE68))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrLinkVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x1638FF0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ClientMessage, ClientMessageNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerFacingAngle, ((void (*)(RPCParameters*))(OrGameRpc(0x16382CC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DisableCheckpoint, ((void (*)(RPCParameters*))(OrGameRpc(0x163FD60))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrShowTextDraw, TraceShowTextDraw);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldTime, ((void (*)(RPCParameters*))(OrGameRpc(0x1639988))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_PlayAudioStream, ((void (*)(RPCParameters*))(OrGameRpc(0x1641354))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetArmedWeapon, OrBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldVehicleRemove, OrBlockedRpc);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrApplyActorAnimation, ((void (*)(RPCParameters*))(OrGameRpc(0x163F564))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerRemove, SafeWorldPlayerRemove);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ExitVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x1636814))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DisableRaceCheckpoint, ((void (*)(RPCParameters*))(OrGameRpc(0x1640004))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_Pickup, ((void (*)(RPCParameters*))(OrGameRpc(0x1636DC0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSelectTextDraw, ((void (*)(RPCParameters*))(OrGameRpc(0x1637DFC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ChatBubble, ChatBubbleNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetInterior, ((void (*)(RPCParameters*))(OrGameRpc(0x1638BB0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrHideTextDraw, ((void (*)(RPCParameters*))(OrGameRpc(0x1637C20))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateExplosion, ((void (*)(RPCParameters*))(OrGameRpc(0x163A3AC))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_SetActorPos, ((void (*)(RPCParameters*))(OrGameRpc(0x1639FB4))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_HideActor, ((void (*)(RPCParameters*))(OrGameRpc(0x1639E08))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectatePlayer, ((void (*)(RPCParameters*))(OrGameRpc(0x163CF64))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrEditTextDraw, EditTextDrawNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPutPlayerInVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x1638E24))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreate3DTextLabel, SafeCreate3DTextLabel);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetSpawnInfo, ((void (*)(RPCParameters*))(OrGameRpc(0x1637F90))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraBehindPlayer, ((void (*)(RPCParameters*))(OrGameRpc(0x1638B78))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPos, ((void (*)(RPCParameters*))(OrGameRpc(0x16369D8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_DestroyPickup, ((void (*)(RPCParameters*))(OrGameRpc(0x1636FA8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParamsEx, ((void (*)(RPCParameters*))(OrGameRpc(0x163D28C))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerControllable, ((void (*)(RPCParameters*))(OrGameRpc(0x163A4D8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectateVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x163D074))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ServerJoin, ((void (*)(RPCParameters*))(OrGameRpc(0x16338B0))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveGangZone, ((void (*)(RPCParameters*))(OrGameRpc(0x1647010))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_WorldPlayerAdd, ((void (*)(RPCParameters*))(OrGameRpc(0x1633D44))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_RequestSpawn, ((void (*)(RPCParameters*))(OrGameRpc(0x1633D20))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDisplayGameText, GameTextNew);
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerName, ((void (*)(RPCParameters*))(OrGameRpc(0x163A7D0))));
  // Accessories: converted for the game's "Attach object RPC" handler.
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerAttachedObject, SetPlayerAttachedObjectToGame);
  // Vehicle custom data (u16 vehicle, u8 type, ...): type 14 = fuel + mileage for the speedometer,
  // the other types are tuning (neon, wheels, suspension...). Same layout as the game handler.
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCustomizeVehicle, ((void (*)(RPCParameters*))(OrGameRpc(0x1641D58))));
  // Common stuff (u8 type, ...): type 7 = license plate text on a vehicle, 26 = GPS point,
  // 0 = clean chat, 5 = drift, 32 = suit level. Same layout as the game handler (0x16423A8).
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCommonStuff, ((void (*)(RPCParameters*))(OrGameRpc(0x16423A8))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateObject, ((void (*)(RPCParameters*))(OrGameRpc(0x163AB44))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrCreateWayPoint, (void (*)(RPCParameters*))((OrGameRpc(0x1637244))));
  pInterface->RegisterAsRemoteProcedureCall(&RPC_ScrDestroyWayPoint, (void (*)(RPCParameters*))((OrGameRpc(0x16373A4))));
  RegisterGameExtraRPCs(pInterface);
}


