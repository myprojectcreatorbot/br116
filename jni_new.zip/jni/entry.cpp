// ONLINE RUSSIA (Black Russia client)

#include "entry.h"
#include "xorstr.h"

#include <array>
#include <cstdint>
#include <cstring>


JavaVM* g_jvm = nullptr;
jclass g_jsonTransportClass = nullptr;
jmethodID g_errorDialogMethod = nullptr;

namespace
{
void StartupError(const char* message)
{
    if (!g_jvm || !g_jsonTransportClass || !g_errorDialogMethod) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (g_jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    if (env) {
        jstring text = env->NewStringUTF(message);
        if (text) {
            env->CallStaticVoidMethod(g_jsonTransportClass, g_errorDialogMethod, text);
            env->DeleteLocalRef(text);
        }
        if (env->ExceptionCheck()) env->ExceptionClear();
    }
    if (attached) g_jvm->DetachCurrentThread();
}
}

extern "C"
jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    g_jvm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
        return JNI_ERR;

    jclass transport = env->FindClass("com/blackhub/bronline/game/core/JNIJSONTransport");
    if (transport) {
        g_errorDialogMethod = env->GetStaticMethodID(transport, "showErrorDialog", "(Ljava/lang/String;)V");
        if (g_errorDialogMethod) g_jsonTransportClass = static_cast<jclass>(env->NewGlobalRef(transport));
        env->DeleteLocalRef(transport);
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    
    CApp::Initialise(eAppInit::APP_INIT_OFFSETS);
    
    pthread_t ptid;
    if (pthread_create(&ptid, NULL, hack_thread, NULL) != 0) {
        return JNI_ERR;
    }
    pthread_detach(ptid);

    
    return JNI_VERSION_1_6;
}

extern RakClientInterface* pRakClient;

void* hack_thread(void* args)
{
	while(!CGameAPI::GetBase()) {
        usleep(10000);
    }

    if (!CGameAPI::ValidateEngineBuild()) {
        StartupError("ONLINE RUSSIA: incompatible game library. Use the tested Black Russia APK.");
        return nullptr;
    }

    RegisterRPCs(pRakClient);
    HideDebugCoords();

    static void* thunkOriginals[4] = {};
    void* targets[] = {
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClient::Connect"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClient::Send"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClient::RPC"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("CChat::AddDebugMessage"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("CNetGame::ProcessNetwork"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClientInterface::Connect"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClientInterface::Send"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClientInterface::RPC"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClient::IsConnected"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("RakClientInterface::IsConnected"))),
        reinterpret_cast<void*>(CGameAPI::GetBase(xorstr("ServerItem::FromJson")))
    };
    void* replacements[] = {
        reinterpret_cast<void*>(&hook_RakClient__Connect),
        reinterpret_cast<void*>(&hook_RakClient__Send),
        reinterpret_cast<void*>(&hook_RakClient__RPC),
        reinterpret_cast<void*>(&hook_CChat__AddDebugMessage),
        reinterpret_cast<void*>(&hook_CNetGame__ProcessNetwork),
        reinterpret_cast<void*>(&hook_RakClient__Connect),
        reinterpret_cast<void*>(&hook_RakClient__Send),
        reinterpret_cast<void*>(&hook_RakClient__RPC),
        reinterpret_cast<void*>(&hook_RakClient__IsConnected),
        reinterpret_cast<void*>(&hook_RakClient__IsConnected),
        reinterpret_cast<void*>(&hook_ServerItem__FromJson)
    };
    void** originals[] = {
        reinterpret_cast<void**>(&orig_RakClient__Connect),
        reinterpret_cast<void**>(&orig_RakClient__Send),
        reinterpret_cast<void**>(&orig_RakClient__RPC),
        reinterpret_cast<void**>(&orig_CChat__AddDebugMessage),
        reinterpret_cast<void**>(&orig_CNetGame__ProcessNetwork),
        &thunkOriginals[0],
        &thunkOriginals[1],
        &thunkOriginals[2],
        reinterpret_cast<void**>(&orig_RakClient__IsConnected),
        &thunkOriginals[3],
        reinterpret_cast<void**>(&orig_ServerItem__FromJson)
    };
    // Необязательные хуки (последний — ServerItem::FromJson): в 32-битной сборке его нет, просто пропускаем
    const size_t kRequiredHooks = 10;
    for (size_t i = 0; i < sizeof(targets) / sizeof(targets[0]); ++i) {
        const uintptr_t address = reinterpret_cast<uintptr_t>(targets[i]);
        if (!address && i >= kRequiredHooks) continue;
        if (!address || !CGameAPI::IsEngineRange(address, 4, true)) {
            StartupError("ONLINE RUSSIA: hook target is outside game executable memory.");
            return nullptr;
        }
    }
    for (size_t i = 0; i < sizeof(targets) / sizeof(targets[0]); ++i) {
        if (!targets[i] && i >= kRequiredHooks) continue;
        const int status = DobbyHook(targets[i], replacements[i], originals[i]);
        if (status != RS_SUCCESS || !*originals[i]) {
            StartupError("ONLINE RUSSIA: network hooks failed. Restart with the tested APK.");
            return nullptr;
        }
    }

	
	pthread_exit(nullptr);
    return nullptr;
}
