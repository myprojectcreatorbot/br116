// ONLINE RUSSIA (Black Russia client)
#pragma once

#include <cstdint>

#include "common.h"

class CRemotePlayer
{
public:
	uint32_t m_modelIndex;
	void* m_pPlayerPed;
	uint8_t m_szName[25];
	uint16_t m_playerId;
};

