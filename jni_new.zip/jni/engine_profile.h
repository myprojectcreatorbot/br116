// ONLINE RUSSIA (Black Russia client)
#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace EngineProfile
{
inline bool MatchesNote(const unsigned char* notes, size_t size,
                        const unsigned char* expected, size_t expectedSize)
{
    size_t cursor = 0;
    while (size - cursor >= 12) {
        uint32_t nameSize, descSize, type;
        std::memcpy(&nameSize, notes + cursor, 4);
        std::memcpy(&descSize, notes + cursor + 4, 4);
        std::memcpy(&type, notes + cursor + 8, 4);
        cursor += 12;
        const uint64_t nameAligned = (uint64_t(nameSize) + 3) & ~uint64_t(3);
        const uint64_t descAligned = (uint64_t(descSize) + 3) & ~uint64_t(3);
        if (nameAligned > size - cursor || descAligned > size - cursor - nameAligned)
            return false;
        if (type == 3 && nameSize == 4 && descSize == expectedSize &&
            std::memcmp(notes + cursor, "GNU", 4) == 0 &&
            std::memcmp(notes + cursor + nameAligned, expected, expectedSize) == 0)
            return true;
        cursor += static_cast<size_t>(nameAligned + descAligned);
    }
    return false;
}

#if defined(__aarch64__)
// 16.116: TH2 20532
inline constexpr unsigned char BuildId[] = {0x6c, 0xf7, 0x9e, 0x81, 0x4f, 0xb7, 0xb2, 0xd8, 0x5a, 0x96, 0x0c, 0x99, 0xec, 0xdb, 0x95, 0x06, 0x04, 0xde, 0x4e, 0xb1};
inline constexpr unsigned char BuildId2[] = {0x6c, 0xf7, 0x9e, 0x81, 0x4f, 0xb7, 0xb2, 0xd8, 0x5a, 0x96, 0x0c, 0x99, 0xec, 0xdb, 0x95, 0x06, 0x04, 0xde, 0x4e, 0xb1};
#else
// 16.116: TH2 20532, armeabi-v7a (10e6f109ed6e20d95537eb72dc7511bb7e447d25)
inline constexpr unsigned char BuildId[] = {0x10, 0xe6, 0xf1, 0x09, 0xed, 0x6e, 0x20, 0xd9, 0x55, 0x37, 0xeb, 0x72, 0xdc, 0x75, 0x11, 0xbb, 0x7e, 0x44, 0x7d, 0x25};
inline constexpr unsigned char BuildId2[] = {0x10, 0xe6, 0xf1, 0x09, 0xed, 0x6e, 0x20, 0xd9, 0x55, 0x37, 0xeb, 0x72, 0xdc, 0x75, 0x11, 0xbb, 0x7e, 0x44, 0x7d, 0x25};
#endif
}
