// ONLINE RUSSIA (Black Russia client)

#include "offsets.h"
#include "xorstr.h"

std::vector<COffset::stOffset> COffset::m_offsets;

void COffset::Initialise()
{
	Add(xorstr("CNetGame::ProcessNetwork"), 0x1615380, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_TurnLightsSync"), 0x1619278, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_GUI"), 0x1619360, eArchType::ARM64);
	Add(xorstr("CNetGame::Packet_TrailerSync"), 0x16189C0, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pRakClient"), 0x352A560, eArchType::ARM64);
	Add(xorstr("CNetGame::m_iGameState"), 0x352A568, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pPlayerPool"), 0x352A570, eArchType::ARM64);
	Add(xorstr("CNetGame::m_pVehiclePool"), 0x352A578, eArchType::ARM64);
	Add(xorstr("CNetVehiclePool::New"), 0x165FCC4, eArchType::ARM64);
	Add(xorstr("CChat::AddDebugMessage"), 0xBF86A4, eArchType::ARM64);
	Add(xorstr("RakClient::Connect"), 0x1911A88, eArchType::ARM64);
	Add(xorstr("RakClient::Send"), 0x1911D88, eArchType::ARM64);
	Add(xorstr("RakClient::RPC"), 0x1912490, eArchType::ARM64);
	Add(xorstr("RakClientInterface::Connect"), 0x1911B28, eArchType::ARM64);
	Add(xorstr("RakClientInterface::Send"), 0x1911DEC, eArchType::ARM64);
	Add(xorstr("RakClientInterface::RPC"), 0x19124FC, eArchType::ARM64);
	// 16.116: GUI-отправка проверяет IsConnected() игрового RakClient (в 16.111 не проверяла)
	Add(xorstr("RakClient::IsConnected"), 0x19120DC, eArchType::ARM64);
	Add(xorstr("RakClientInterface::IsConnected"), 0x19120F8, eArchType::ARM64);
	// 16.116: разбор сервера из списка лаунчера (json -> ServerItem), поле name = +0xE0
	Add(xorstr("ServerItem::FromJson"), 0x13725CC, eArchType::ARM64);
	// 16.116 cbt2: байт "показывать координаты" (в .data = 1), в релизе 16.111 координат нет
	Add(xorstr("Debug::ShowCoords"), 0x20E2128, eArchType::ARM64);

	// ---- 32 бит (armeabi-v7a), тот же билд 16.116 TH2 20532; Thumb-функции с битом 1 ----
	Add(xorstr("CNetGame::ProcessNetwork"), 0xDC8D31, eArchType::ARM);
	Add(xorstr("CNetGame::Packet_TurnLightsSync"), 0xDCCD0D, eArchType::ARM);
	Add(xorstr("CNetGame::Packet_GUI"), 0xDCCDB1, eArchType::ARM);
	Add(xorstr("CNetGame::Packet_TrailerSync"), 0xDCC615, eArchType::ARM);
	Add(xorstr("CNetGame::m_pRakClient"), 0x21EECB8, eArchType::ARM);
	Add(xorstr("CNetGame::m_iGameState"), 0x21EECBC, eArchType::ARM);
	Add(xorstr("CNetGame::m_pPlayerPool"), 0x21EECC0, eArchType::ARM);
	Add(xorstr("CNetGame::m_pVehiclePool"), 0x21EECC4, eArchType::ARM);
	Add(xorstr("CNetVehiclePool::New"), 0xE05DD1, eArchType::ARM);
	Add(xorstr("CChat::AddDebugMessage"), 0x5E56A9, eArchType::ARM);
	Add(xorstr("RakClient::Connect"), 0x103395D, eArchType::ARM);
	Add(xorstr("RakClient::Send"), 0x1033B99, eArchType::ARM);
	Add(xorstr("RakClient::RPC"), 0x10341D5, eArchType::ARM);
	Add(xorstr("RakClientInterface::Connect"), 0x10339C1, eArchType::ARM);
	Add(xorstr("RakClientInterface::Send"), 0x1033C01, eArchType::ARM);
	Add(xorstr("RakClientInterface::RPC"), 0x1034241, eArchType::ARM);
	Add(xorstr("RakClient::IsConnected"), 0x1033F85, eArchType::ARM);
	Add(xorstr("RakClientInterface::IsConnected"), 0x1033F97, eArchType::ARM);
	Add(xorstr("Debug::ShowCoords"), 0x15B4E8C, eArchType::ARM);
}

void COffset::Add(const char* name, uintptr_t addr, eArchType arch)
{
	stOffset nOffset;
	nOffset.name = name;
	nOffset.addr = addr;
	nOffset.arch = arch;
	m_offsets.push_back(nOffset);
}

uintptr_t COffset::Get(const char* name)
{
	uintptr_t result = 0;
	for(int i = 0; i < m_offsets.size(); i++)
	{
#if defined(__aarch64__)
		if(m_offsets[i].arch == eArchType::ARM64)
#else
		if(m_offsets[i].arch == eArchType::ARM)
#endif
		{
		if(!strcasecmp(name, m_offsets[i].name.c_str()))
		{
			result = m_offsets[i].addr;
			break;
		}
		}
	}
	return result;
}

