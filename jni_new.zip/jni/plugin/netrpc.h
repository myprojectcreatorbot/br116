// ONLINE RUSSIA (Black Russia client)
#pragma once

#include "vendor/RakNet/RakNetworkFactory.h"
#include "vendor/RakNet/RakClient.h"
#include "vendor/RakNet/SAMP/SAMPRPC.h"

void RegisterRPCs(RakClientInterface* pInterface);

// ONLINE RUSSIA: кнопка нитро в машине (игровой RPC 444). level: 0 — нет, 1 = 2X, 2 = 5X, 3 = 10X
void OrApplyVehicleNitro(const RPCParameters* tmpl, uint16_t vehicleId, uint8_t level);
// деталь SA-MP -> уровень нитро: 1009 = 2X, 1008 = 5X, 1010 = 10X, иначе 0
uint8_t OrNitroLevelFromComponent(uint32_t componentId);

